﻿namespace CSCore.ACM
{
    public enum AcmStreamSizeFlags
    {
        Input = 0x00000000,
        Output = 0x00000001
    }
}