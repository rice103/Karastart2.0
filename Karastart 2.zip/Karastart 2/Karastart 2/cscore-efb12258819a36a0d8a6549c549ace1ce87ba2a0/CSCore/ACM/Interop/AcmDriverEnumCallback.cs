﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSCore.ACM
{
    public delegate bool AcmDriverEnumCallback(IntPtr hadid, IntPtr instance, AcmDriverDetailsSupport support);
}
