﻿namespace CSCore.SoundOut.DirectSound
{
    public enum DSEffectFlags : int
    {
        Default = 0,
        LocHardware = 1,
        LocSoftware = 2
    }
}