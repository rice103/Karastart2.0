﻿namespace CSCore.SoundOut.DirectSound
{
    /*
     #define DS_CERTIFIED                0x00000000
     #define DS_UNCERTIFIED              0x00000001
     */

    public enum DSCertification
    {
        Certified = 0,
        Uncertified = 1
    }
}