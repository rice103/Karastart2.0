﻿namespace CSCore.SoundOut.DirectSound
{
    public enum DSMode3D
    {
        Normal = 0x00000000,
        HeadRelative = 0x00000001,
        Disable = 0x00000002
    }
}