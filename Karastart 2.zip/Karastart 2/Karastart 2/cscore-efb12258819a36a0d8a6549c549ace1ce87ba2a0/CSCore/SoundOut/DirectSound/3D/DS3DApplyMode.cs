﻿namespace CSCore.SoundOut.DirectSound
{
    public enum DS3DApplyMode
    {
        Immediate = 0,
        Deferred = 1
    }
}