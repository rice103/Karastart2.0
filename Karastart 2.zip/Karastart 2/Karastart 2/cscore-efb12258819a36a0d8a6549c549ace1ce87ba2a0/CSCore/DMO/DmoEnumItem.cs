﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSCore.DMO
{
    public struct DmoEnumItem
    {
        public Guid CLSID { get; set; }
        public string Name { get; set; }
    }
}
