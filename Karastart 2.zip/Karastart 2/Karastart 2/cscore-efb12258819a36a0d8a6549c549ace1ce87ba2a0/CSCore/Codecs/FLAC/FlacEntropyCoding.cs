﻿namespace CSCore.Codecs.FLAC
{
    public enum FlacEntropyCoding
    {
        PartitionedRice = 0x0,
        PartitionedRice2 = 0x1,
        INVALID2 = 0x2, //10
        IVANLID3 = 0x3 // 11
    }
}