﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSCore.MediaFoundation
{
    public enum MFAttributeMatchType
    {
        OurItems = 0,
        TheirItems = 1,
        AllItems = 2,
        Intersection = 3,
        Smaller = 4
    }
}