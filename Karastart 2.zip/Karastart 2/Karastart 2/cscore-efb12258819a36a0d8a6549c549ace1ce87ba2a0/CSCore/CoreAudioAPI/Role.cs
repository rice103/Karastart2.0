﻿namespace CSCore.CoreAudioAPI
{
    public enum Role
    {
        Console = 0,
        Multimedia = Console + 1,
        Communications = Multimedia + 1,
    }
}