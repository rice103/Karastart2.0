﻿namespace CSCore.CoreAudioAPI
{
    public enum StorageAccess
    {
        Read = 0x00000000,
        Write = 0x00000001,
        ReadWrite = 0x00000002
    }
}