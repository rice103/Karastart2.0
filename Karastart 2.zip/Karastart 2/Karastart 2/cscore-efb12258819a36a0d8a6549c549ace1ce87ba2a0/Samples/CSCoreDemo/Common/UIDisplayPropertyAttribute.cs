﻿using System;

namespace CSCoreDemo
{
    [AttributeUsage(AttributeTargets.Property)]
    public class UIDisplayPropertyAttribute : Attribute
    {
    }
}