﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSCore.Visualization
{
    public interface IVisualization
    {
        bool EnableRendering { get; set; }
    }
}