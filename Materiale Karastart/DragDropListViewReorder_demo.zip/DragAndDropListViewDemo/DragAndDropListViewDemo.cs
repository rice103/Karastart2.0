using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using Bol.WinControls;

namespace DragAndDropListViewDemo
{
	/// <summary>
	/// Summary description for DragAndDropListViewDemo.
	/// </summary>
	public class DragAndDropListViewDemo : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button closeBtn;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DragAndDropListViewDemo()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			CustomInitializeComponent();
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.closeBtn = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Drag and Drop Item";
			this.columnHeader1.Width = 294;
			// 
			// groupBox1
			// 
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(304, 288);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			// 
			// closeBtn
			// 
			this.closeBtn.Location = new System.Drawing.Point(104, 296);
			this.closeBtn.Name = "closeBtn";
			this.closeBtn.TabIndex = 1;
			this.closeBtn.Text = "&Close";
			this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
			// 
			// DragAndDropListViewDemo
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(304, 325);
			this.Controls.Add(this.closeBtn);
			this.Controls.Add(this.groupBox1);
			this.Name = "DragAndDropListViewDemo";
			this.Text = "DragAndDropListViewDemo";
			this.ResumeLayout(false);
		}
		#endregion
		
		protected void CustomInitializeComponent()
		{
			Bol.WinControls.ListViewEx listView = new Bol.WinControls.ListViewEx();
			listView.Dock = DockStyle.Fill;
			listView.View = View.Details;
			listView.Columns.Add("Items", 100, HorizontalAlignment.Center);
			this.groupBox1.Controls.Add(listView);
			for(int i=0;i<100;i++)
			{
				listView.Items.Add(i.ToString());
			}
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new DragAndDropListViewDemo());
		}

		private void closeBtn_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
